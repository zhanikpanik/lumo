import { useState, useMemo, useCallback } from 'react';
import { toast } from 'sonner';
import { Banknote, Receipt, Users, Calculator, Wallet, UserRound } from 'lucide-react';
import warehouseIcon from '@/assets/icons/warehouse.svg?raw';
import clockIcon from '@/assets/icons/clock.svg?raw';
import receiptIcon from '@/assets/icons/sheet-of-paper.svg?raw';
import walletIcon from '@/assets/icons/wallet.svg?raw';
import undoIcon from '@/assets/icons/undo.svg?raw';
import trashIcon from '@/assets/icons/trashcan.svg?raw';
import clipboardIcon from '@/assets/icons/clipboard.svg?raw';
import truckIcon from '@/assets/icons/truck.svg?raw';
import { useDashboardNewData, type DashboardPeriod } from '@/hooks/useDashboardNewData';
import { getMockData } from '@/hooks/useDashboardMockData';
import { SegmentTabs } from '@/components/ui/SegmentTabs';
import { ActionBar } from '@/components/dashboard/ActionBar';
import { MetricCard } from '@/components/dashboard/MetricCard';
import { AlertCard } from '@/components/dashboard/AlertCard';
import { MigrationCard } from '@/components/dashboard/MigrationCard';
import { ChronologyFeed } from '@/components/dashboard/ChronologyFeed';
import { WarehouseThreats } from '@/components/dashboard/WarehouseThreats';
import { YesterdayBar } from '@/components/dashboard/YesterdayBar';
import { TopDishesCard } from '@/components/dashboard/TopDishesCard';

const metricIcons = [Banknote, Calculator, Receipt, Users, Wallet, UserRound];

const PERIOD_OPTIONS: { value: DashboardPeriod; label: string }[] = [
  { value: 'today', label: 'Сегодня' },
  { value: 'week', label: 'Неделя' },
  { value: 'month', label: 'Месяц' },
];

const severityOrder: Record<string, number> = {
  critical: 0,
  warning: 1,
  info: 2,
};

function fmtSom(n: number): string {
  return n.toLocaleString('ru-RU');
}

/** Map alert id prefix → contextual SVG icon */
function alertIconSrc(id: string): string | undefined {
  if (id.startsWith('stock-') || id === 'stock-negative' || id === 'stock-zero' || id === 'stock-low') return warehouseIcon;
  if (id.startsWith('stuck-orders') || id.startsWith('shift-') || id === 'no-shift-orders') return clockIcon;
  if (id.startsWith('anomaly-check') || id.startsWith('zero-check') || id.startsWith('suspicious-check')) return receiptIcon;
  if (id.startsWith('shift-discrepancy') || id.startsWith('blank-expense')) return walletIcon;
  if (id.startsWith('many-refund') || id.startsWith('staff-refund')) return undoIcon;
  if (id.startsWith('dead-dish') || id.startsWith('dead-ingredient')) return trashIcon;
  if (id.startsWith('no-inventory') || id.startsWith('stale-inventory')) return clipboardIcon;
  if (id.startsWith('anomaly-delivery')) return truckIcon;
  return undefined;
}

const MOCK = true; // временно — для оценки дизайна

export function Dashboard() {
  const [period, setPeriod] = useState<DashboardPeriod>('today');

  // Labor cost — stored in localStorage (simple venue-level setting)
  const [laborCost, setLaborCost] = useState<number>(() => {
    try {
      return Number(localStorage.getItem('rkeeper_daily_labor_cost')) || 0;
    } catch { return 0; }
  });

  const realQuery = useDashboardNewData(period, laborCost);

  // Mock mode: replace real data with mock
  const mockData = MOCK ? getMockData(period) : null;

  const data = mockData ?? realQuery.data;
  const isPending = MOCK ? false : realQuery.isPending;
  const isError = MOCK ? false : realQuery.isError;
  const error = MOCK ? null : realQuery.error;
  const [laborInput, setLaborInput] = useState<string>('');
  const [showLaborEdit, setShowLaborEdit] = useState(false);

  const handleSaveLabor = useCallback(() => {
    const value = Number(laborInput);
    if (isNaN(value) || value < 0) {
      toast.error('Введите сумму');
      return;
    }
    setLaborCost(value);
    try { localStorage.setItem('rkeeper_daily_labor_cost', String(value)); } catch {}
    toast.success(`Зарплаты: ${value.toLocaleString('ru-RU')} сом/день`);
    setShowLaborEdit(false);
  }, [laborInput]);

  const laborDisplay = laborCost > 0 ? `${laborCost.toLocaleString('ru-RU')} сом` : 'Не указано';

  const [dismissedAlertIds, setDismissedAlertIds] = useState<Set<string>>(new Set());
  const [dismissedMigrationIds, setDismissedMigrationIds] = useState<Set<string>>(new Set());

  // Migration cards suppress their domain alerts
  const alerts = useMemo(() => {
    if (!data) return [];
    const cards = data.migrationCards ?? [];
    const migrationDomains = new Set<string>(cards
      .filter((c) => !dismissedMigrationIds.has(c.id))
      .map((c) => {
        if (c.id === 'migrate-warehouse') return 'warehouse';
        if (c.id === 'migrate-checks') return 'checks';
        if (c.id === 'migrate-cash') return 'cash';
        return '';
      }));
    return (data.alerts ?? [])
      .filter((a) => !dismissedAlertIds.has(a.id) && !migrationDomains.has(a.domain))
      .sort((a, b) => (severityOrder[a.type] ?? 99) - (severityOrder[b.type] ?? 99));
  }, [data, dismissedAlertIds, dismissedMigrationIds]);

  const migrationCards = useMemo(() => {
    if (!data) return [];
    return (data.migrationCards ?? []).filter((c) => !dismissedMigrationIds.has(c.id));
  }, [data, dismissedMigrationIds]);

  const handleDismissAlert = (id: string) => {
    setDismissedAlertIds((prev) => new Set(prev).add(id));
  };

  const handleDismissMigration = (id: string) => {
    setDismissedMigrationIds((prev) => new Set(prev).add(id));
    toast('Карточка миграции скрыта', { duration: 3000 });
  };

  if (isError) {
    return (
      <div className="min-h-full bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-destructive font-medium">Ошибка загрузки дашборда</p>
          <p className="text-sm text-muted-foreground mt-1">
            {error instanceof Error ? error.message : 'Попробуйте обновить страницу'}
          </p>
        </div>
      </div>
    );
  }

  const metrics = data?.metrics ?? [];
  const yesterday = data?.yesterday;
  const warehouseThreats = data?.warehouseThreats ?? [];
  const topDishes = data?.topDishes ?? [];
  const antiTop = data?.antiTop ?? [];
  const chronology = data?.chronology ?? [];
  const isTodayEmpty = data?.isTodayEmpty ?? false;
  const weekRevenue = (data as any)?.weekRevenue ?? 0;
  const weekChecks = (data as any)?.weekChecks ?? 0;
  const totalAlertCount = data?.totalAlertCount ?? 0;
  const criticalCount = data?.criticalCount ?? 0;
  const periodLabel = data?.periodLabel ?? 'сегодня';

  const showAlerts = alerts.length > 0;
  const hasMigration = migrationCards.length > 0;

  return (
    <div className="min-h-full bg-background">
      <ActionBar criticalCount={criticalCount} totalAlertCount={totalAlertCount} />

      <div className="max-w-6xl mx-auto p-4 sm:p-6 space-y-8">

        {/* ═══ PERIOD SELECTOR ═══ */}
        <SegmentTabs options={PERIOD_OPTIONS} value={period} onChange={setPeriod} />

        {/* ═══ LABOR COST EDITOR ═══ */}
        {showLaborEdit && (
          <div className="flex items-center gap-2 text-sm bg-[#EFF1F3] rounded-xl px-4 py-3">
            <span className="text-muted-foreground">Персонал в день:</span>
            <input
              type="number"
              value={laborInput}
              onChange={(e) => setLaborInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSaveLabor()}
              placeholder={laborCost > 0 ? String(laborCost) : 'сом'}
              className="w-24 px-2 py-1 border border-border rounded-lg text-sm tabular-nums"
              autoFocus
            />
            <button
              onClick={handleSaveLabor}
              className="px-3 py-1.5 bg-primary text-primary-foreground rounded-lg text-sm font-medium"
            >
              Сохранить
            </button>
            <button
              onClick={() => setShowLaborEdit(false)}
              className="px-2 py-1 text-muted-foreground hover:text-foreground text-sm"
            >
              Отмена
            </button>
          </div>
        )}

        {/* ═══ TODAY EMPTY FALLBACK ═══ */}
        {isTodayEmpty && period === 'today' && weekRevenue > 0 && (
          <div className="text-sm text-muted-foreground bg-[#EFF1F3] rounded-xl px-4 py-3 border border-border/30">
            <span className="font-medium text-foreground">Сегодня заказов пока нет.</span>
            {' '}За неделю: <span className="font-medium text-foreground">{weekRevenue.toLocaleString('ru-RU')} сом</span>, {weekChecks} чеков.
          </div>
        )}

        {/* ═══ KPI METRICS ═══ */}
        {isPending && (
          <div className="bg-[#EFF1F3] rounded-xl p-5 opacity-60">
            <p className="text-sm text-muted-foreground mb-4">Загрузка данных{period === 'today' ? ' за сегодня' : period === 'week' ? ' за неделю' : ' за месяц'}...</p>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 divide-x divide-border/30">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className={i === 0 ? 'pr-4' : i === 5 ? 'pl-4' : 'px-4'}>
                  <div className="h-4 bg-muted rounded w-20 mb-2" />
                  <div className="h-7 bg-muted rounded w-24 mb-1" />
                  <div className="h-3 bg-muted rounded w-12" />
                </div>
              ))}
            </div>
          </div>
        )}

        {metrics.length > 0 && (
          <div className="bg-[#EFF1F3] rounded-xl p-4 sm:p-5 transition-opacity duration-300">
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 divide-x divide-border/30">
              {metrics.map((metric, i) => (
                <div key={metric.label} className={i === 0 ? 'pr-3 sm:pr-4' : i === metrics.length - 1 ? 'pl-3 sm:pl-4' : 'px-3 sm:px-4'}>
                  <MetricCard
                    label={metric.label}
                    value={metric.value}
                    format={metric.format}
                    trend={metric.trend}
                    tooltip={metric.tooltip}
                    icon={metricIcons[i]}
                  />
                </div>
              ))}
              {/* Labor cost — 6th card, editable */}
              <div
                className="pl-3 sm:pl-4 cursor-pointer hover:opacity-80 transition-opacity"
                onClick={() => {
                  setLaborInput(laborCost > 0 ? String(laborCost) : '');
                  setShowLaborEdit(!showLaborEdit);
                }}
              >
                <div className="flex flex-col gap-2 min-w-0">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="w-7 h-7 rounded-full flex items-center justify-center shrink-0 text-primary bg-primary/10">
                      <UserRound className="w-3.5 h-3.5" />
                    </span>
                    <p className="text-sm text-muted-foreground truncate">Персонал</p>
                  </div>
                  <div className="flex items-baseline gap-1 min-w-0">
                    <span className="text-2xl font-semibold text-foreground truncate">
                      {laborCost > 0 ? laborCost.toLocaleString('ru-RU') : '—'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ═══ MIGRATION CARDS ═══ */}
        {hasMigration && (
          <div className="space-y-2">
            {migrationCards.map((card) => (
              <MigrationCard
                key={card.id}
                card={card}
                onDismiss={handleDismissMigration}
              />
            ))}
          </div>
        )}

        {/* ═══ YESTERDAY + PROFIT — 2 columns ═══ */}
        {!isTodayEmpty && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {yesterday && <YesterdayBar data={yesterday} />}
            {data?.operationalResult && (
              <div className={`rounded-xl px-4 py-2.5 ${
                data.operationalResult.net >= 0 ? 'bg-emerald-50/50' : 'bg-amber-50/50'
              }`}>
                <div className="flex items-center justify-between h-full">
                  <div>
                    <p className="text-sm text-muted-foreground">Прибыль</p>
                    <p className="text-xl font-bold tabular-nums">
                      {data.operationalResult.net >= 0 ? '+' : ''}{fmtSom(data.operationalResult.net)} сом
                    </p>
                  </div>
                  <div className="text-right text-sm text-muted-foreground">
                    <p>Выручка: {fmtSom(data.operationalResult.revenue)} сом</p>
                    <p>Расходы: {fmtSom(data.operationalResult.expenses)} сом</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ═══ ALERTS — grouped block ═══ */}
        {showAlerts && (
          <div id="alerts" className="bg-[#EFF1F3] rounded-xl overflow-hidden scroll-mt-14">
            {alerts.map((alert) => (
              <AlertCard
                key={alert.id}
                type={alert.type}
                message={alert.message}
                actionLabel={alert.actionLabel}
                actionHref={alert.actionHref}
                onDismiss={() => handleDismissAlert(alert.id)}
                iconRaw={alertIconSrc(alert.id)}
                grouped
              />
            ))}
          </div>
        )}

        {/* ═══ WAREHOUSE ═══ */}
        <WarehouseThreats threats={warehouseThreats} loaded={!isPending} />

        {/* ═══ CHRONOLOGY — always today ═══ */}
        <ChronologyFeed
          events={chronology}
          title="События за сегодня"
        />

        {/* ═══ TOP DISHES + ANTI-TOP — two columns ═══ */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <TopDishesCard dishes={topDishes.slice(0, 5)} title={data?.topDishesTitle} antiTop={[]} />
          <TopDishesCard dishes={[]} title="Низкая маржа" antiTop={antiTop} />
        </div>


      </div>
    </div>
  );
}

function pluralize(n: number, one: string, two: string, many: string): string {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod100 >= 11 && mod100 <= 19) return many;
  if (mod10 === 1) return one;
  if (mod10 >= 2 && mod10 <= 4) return two;
  return many;
}
