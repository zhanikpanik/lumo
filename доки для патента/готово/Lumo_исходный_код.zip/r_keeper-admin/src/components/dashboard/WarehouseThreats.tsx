import { CheckCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
import { cn } from '@/lib/utils';
import type { WarehouseThreat } from '@/types/dashboard';

interface WarehouseThreatsProps {
  threats: WarehouseThreat[];
  loaded?: boolean | null;
}

const MAX_VISIBLE_PER_WAREHOUSE = 6;

export function WarehouseThreats({ threats, loaded = true }: WarehouseThreatsProps) {
  if (threats.length === 0) {
    return (
      <div>
        <h2 className="text-base font-medium text-foreground mb-1">Остатки на складе</h2>
        {loaded === false ? (
          <p className="text-sm text-muted-foreground">Нет данных — обновите инвентаризацию</p>
        ) : loaded === null ? (
          <p className="text-sm text-muted-foreground">Склад не настроен — добавьте склад в настройках</p>
        ) : (
          <p className="text-sm text-success flex items-center gap-1.5">
            <CheckCircle className="w-3.5 h-3.5" />
            Запасов хватает
          </p>
        )}
        <Link to="/warehouse/inventory" className="inline-block mt-1 text-sm font-medium text-primary hover:underline">
          Перейти на склад →
        </Link>
      </div>
    );
  }

  // Deduplicate by product name
  const seen = new Set<string>();
  const unique: WarehouseThreat[] = [];
  for (const t of threats) {
    if (!seen.has(t.name)) {
      seen.add(t.name);
      unique.push(t);
    }
  }

  // Group by warehouse
  const byWarehouse = new Map<string, WarehouseThreat[]>();
  for (const t of unique) {
    const key = t.warehouseName || 'Прочее';
    if (!byWarehouse.has(key)) byWarehouse.set(key, []);
    byWarehouse.get(key)!.push(t);
  }

  // Only show warehouses that actually have threats
  const problemWarehouses = Array.from(byWarehouse.entries());

  // Check if any warehouse has no threats (was filtered out)
  // If some are fine, note it below the table
  const allWarehouseNames = [...new Set(threats.map(t => t.warehouseName).filter(Boolean))];
  const problemNames = new Set(problemWarehouses.map(([n]) => n));
  const cleanNames = allWarehouseNames.filter(n => !problemNames.has(n));

  return (
    <>
      <h2 className="text-base font-medium text-foreground mb-2">Остатки на складе</h2>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {problemWarehouses.map(([whName, items]) => {
          const visible = items.slice(0, MAX_VISIBLE_PER_WAREHOUSE);
          const overflow = items.length - MAX_VISIBLE_PER_WAREHOUSE;

          return (
            <div key={whName}>
              <h3 className="text-sm font-medium text-foreground mb-1">{whName}</h3>
              {/* Per-warehouse column header */}
              <div className="flex items-center gap-2 py-1 text-sm text-muted-foreground border-b border-border/20">
                <span className="flex-1 min-w-0">Ингредиент</span>
                <span className="shrink-0 text-right w-[80px]">Остаток</span>
                <span className="shrink-0 text-right w-[110px]">Поставка</span>
              </div>

              {visible.map((threat, i) => (
                <div
                  key={threat.name}
                  className={cn(
                    'flex items-center gap-2 py-1.5 text-sm',
                    i < visible.length - 1 || overflow > 0 ? 'border-b border-border/20' : '',
                  )}
                >
                  <span className="text-foreground flex-1 min-w-0 truncate">{threat.name}</span>
                  <span className="text-muted-foreground shrink-0 text-right tabular-nums w-[80px]">
                    {threat.remaining}
                  </span>
                  <span className="text-muted-foreground shrink-0 text-right w-[110px]">
                    {threat.lastDelivery || '—'}
                  </span>
                </div>
              ))}

              {overflow > 0 && (
                <p className="text-sm text-muted-foreground mt-1">+ ещё {overflow}</p>
              )}
            </div>
          );
        })}
      </div>

      {cleanNames.length > 0 && (
        <p className="text-sm text-muted-foreground mt-1">
          {cleanNames.join(', ')}: запасов хватает
        </p>
      )}

      <Link to="/warehouse/inventory" className="inline-block mt-2 text-sm font-medium text-primary hover:underline">
        Перейти на склад →
      </Link>
    </>
  );
}
