-- Test data migration: triggers all 8 dashboard detectors
-- Run: supabase db push

-- ═══ DETECTOR 2: Без инвентаризации >30 дней ═══
-- Backdate the last inventory session to 35 days ago
UPDATE warehouse_inventory_sessions
SET conducted_at = '2026-05-06T10:00:00+00:00'
WHERE id = '2b15a857-8b96-4fd6-ade7-11e96db98f88'
  AND conducted_at > '2026-05-07';

-- ═══ DETECTOR 3: Аномальная поставка ═══
-- Create a delivery with 4 entries for same product, latest 3x avg
INSERT INTO warehouse_delivery_items (id, delivery_id, product_id, name, quantity, unit, price)
SELECT
  gen_random_uuid(),
  d.id,
  'e0d97529-c333-a74c-8aaa-a02a9e9cbfee', -- Листья Салата
  'Листья Салата',
  qty,
  'г',
  1
FROM (
  SELECT id FROM warehouse_deliveries ORDER BY created_at LIMIT 1
) d,
(VALUES (50), (40), (45), (400)) AS v(qty);

-- ═══ DETECTOR 4: Мёртвое блюдо ═══
INSERT INTO products (id, venue_id, name, type, is_active, created_at, price, cost_price, sort_order)
VALUES (
  'dead0001-0000-0000-0000-000000000001',
  '00000000-0000-0000-0000-000000000010',
  'Тестовое блюдо (мёртвое)',
  'dish',
  true,
  '2026-04-01T00:00:00+00:00',
  500,
  200,
  9999
) ON CONFLICT (id) DO NOTHING;

-- ═══ DETECTOR 5: Мёртвый ингредиент ═══
INSERT INTO products (id, venue_id, name, type, is_active, created_at, price, cost_price, unit, sort_order)
VALUES (
  'dead0002-0000-0000-0000-000000000002',
  '00000000-0000-0000-0000-000000000010',
  'Тестовый ингредиент (мёртвый)',
  'ingredient',
  true,
  '2026-04-01T00:00:00+00:00',
  100,
  50,
  'кг',
  9999
) ON CONFLICT (id) DO NOTHING;

-- Add to stock_items (Бар)
INSERT INTO stock_items (product_id, warehouse_id, quantity, unit, updated_at)
VALUES (
  'dead0002-0000-0000-0000-000000000002',
  '9cf4f3b6-f07e-931a-d03f-cbde7a91d6f1', -- Бар
  5.0,
  'кг',
  '2026-04-01T00:00:00+00:00'
) ON CONFLICT (product_id, warehouse_id) DO NOTHING;

-- ═══ DETECTOR 6: Разрыв кассы ═══
-- Create a closed shift with discrepancy
INSERT INTO shifts (id, venue_id, opened_at, closed_at, starting_cash, expected_cash_at_close, cash_difference)
VALUES (
  'dead0003-0000-0000-0000-000000000003',
  '00000000-0000-0000-0000-000000000010',
  '2026-06-10T08:00:00+00:00',
  '2026-06-10T16:00:00+00:00',
  0,
  5000,
  -750  -- 750 сом расхождения
);

-- Create orders during this shift to calculate revenue
INSERT INTO orders (id, venue_id, status, total_amount, opened_at, table_number)
VALUES
  ('dead0004-0000-0000-0000-000000000004', '00000000-0000-0000-0000-000000000010', 'paid', 3000, '2026-06-10T09:00:00+00:00', 1),
  ('dead0005-0000-0000-0000-000000000005', '00000000-0000-0000-0000-000000000010', 'paid', 2000, '2026-06-10T10:00:00+00:00', 2);
-- Total revenue: 5000, discrepancy: 750 = 15% > 5% threshold ✓

-- ═══ DETECTOR 7: Официант с возвратами ═══
-- Create test staff
INSERT INTO staff (id, venue_id, name, role)
VALUES
  ('dead0006-0000-0000-0000-000000000006', '00000000-0000-0000-0000-000000000010', 'Тестовый Официант', 'waiter'),
  ('dead0007-0000-0000-0000-0000-000000000007', '00000000-0000-0000-0000-000000000010', 'Обычный Официант', 'waiter');

-- Waiter dead0006: 5 orders, 3 refunds (60% return rate)
INSERT INTO orders (id, venue_id, status, total_amount, staff_id, opened_at, table_number)
VALUES
  ('dead0008-0000-0000-0000-000000000008', '00000000-0000-0000-0000-000000000010', 'paid',  1000, 'dead0006-0000-0000-0000-000000000006', '2026-06-09T09:00:00+00:00', 1),
  ('dead0009-0000-0000-0000-000000000009', '00000000-0000-0000-0000-000000000010', 'paid',   800, 'dead0006-0000-0000-0000-000000000006', '2026-06-09T10:00:00+00:00', 1),
  ('dead000a-0000-0000-0000-00000000000a', '00000000-0000-0000-0000-000000000010', 'paid',  -300, 'dead0006-0000-0000-0000-000000000006', '2026-06-09T11:00:00+00:00', 1),
  ('dead000b-0000-0000-0000-00000000000b', '00000000-0000-0000-0000-000000000010', 'paid',  -200, 'dead0006-0000-0000-0000-000000000006', '2026-06-09T12:00:00+00:00', 1),
  ('dead000c-0000-0000-0000-00000000000c', '00000000-0000-0000-0000-000000000010', 'paid',  -150, 'dead0006-0000-0000-0000-000000000006', '2026-06-09T13:00:00+00:00', 1);

-- Waiter dead0007: 10 orders, 1 refund (10% — normal)
INSERT INTO orders (id, venue_id, status, total_amount, staff_id, opened_at, table_number)
VALUES
  ('dead000d-0000-0000-0000-00000000000d', '00000000-0000-0000-0000-000000000010', 'paid',  1200, 'dead0007-0000-0000-0000-000000000007', '2026-06-09T09:00:00+00:00', 2),
  ('dead000e-0000-0000-0000-00000000000e', '00000000-0000-0000-0000-000000000010', 'paid',  1100, 'dead0007-0000-0000-0000-000000000007', '2026-06-09T10:00:00+00:00', 2),
  ('dead000f-0000-0000-0000-00000000000f', '00000000-0000-0000-0000-000000000010', 'paid',  1300, 'dead0007-0000-0000-0000-000000000007', '2026-06-09T11:00:00+00:00', 2),
  ('dead0010-0000-0000-0000-000000000010', '00000000-0000-0000-0000-000000000010', 'paid',   900, 'dead0007-0000-0000-0000-000000000007', '2026-06-09T12:00:00+00:00', 2),
  ('dead0011-0000-0000-0000-000000000011', '00000000-0000-0000-0000-000000000010', 'paid',  1000, 'dead0007-0000-0000-0000-000000000007', '2026-06-09T13:00:00+00:00', 2),
  ('dead0012-0000-0000-0000-000000000012', '00000000-0000-0000-0000-000000000010', 'paid',  -100, 'dead0007-0000-0000-0000-000000000007', '2026-06-09T14:00:00+00:00', 2),
  ('dead0013-0000-0000-0000-000000000013', '00000000-0000-0000-0000-000000000010', 'paid',  1100, 'dead0007-0000-0000-0000-000000000007', '2026-06-09T15:00:00+00:00', 2),
  ('dead0014-0000-0000-0000-000000000014', '00000000-0000-0000-0000-000000000010', 'paid',   950, 'dead0007-0000-0000-0000-000000000007', '2026-06-09T16:00:00+00:00', 2),
  ('dead0015-0000-0000-0000-000000000015', '00000000-0000-0000-0000-000000000010', 'paid',  1050, 'dead0007-0000-0000-0000-000000000007', '2026-06-09T17:00:00+00:00', 2),
  ('dead0016-0000-0000-0000-000000000016', '00000000-0000-0000-0000-000000000010', 'paid',  1200, 'dead0007-0000-0000-0000-000000000007', '2026-06-09T18:00:00+00:00', 2);

-- ═══ DETECTOR 8: Подозрительный чек ═══
-- Order paid for 300, but items added = 5000
INSERT INTO orders (id, venue_id, status, total_amount, opened_at, table_number)
VALUES (
  'dead0017-0000-0000-0000-000000000017',
  '00000000-0000-0000-0000-000000000010',
  'paid',
  300,
  '2026-06-10T09:00:00+00:00',
  5
);

INSERT INTO order_events (id, order_id, action, product_id, product_name, quantity, unit_price, occurred_at, venue_id)
VALUES
  (gen_random_uuid(), 'dead0017-0000-0000-0000-000000000017', 'item_added',
   'e0d97529-c333-a74c-8aaa-a02a9e9cbfee', 'Листья Салата', 10, 300, '2026-06-10T09:05:00+00:00',
   '00000000-0000-0000-0000-000000000010'),
  (gen_random_uuid(), 'dead0017-0000-0000-0000-000000000017', 'item_added',
   'ce07ca59-e737-9a0c-2e3d-15ec5a3bf59d', 'Лук', 5, 400, '2026-06-10T09:06:00+00:00',
   '00000000-0000-0000-0000-000000000010');
-- item_added sum: 10*300 + 5*400 = 3000 + 2000 = 5000
-- paid: 300 → 300 < 5000*0.2 (1000) ✓
