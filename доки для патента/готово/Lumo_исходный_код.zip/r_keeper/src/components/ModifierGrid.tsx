import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { ChevronLeftIcon, ChevronRightIcon } from './Icons';
import { theme } from '../theme/colors';
import { useOrderStore } from '../store/orderStore';
import { Modifier } from '../types';
import { Numpad } from './Numpad';
import { DishCommentPanel } from './DishCommentPanel';
import { DeleteOptions } from './DeleteOptions';
import { useMenuStore } from '../store/menuStore';

const COLS = 3;
const ROWS = 5;
const MODIFIER_ROWS = ROWS;
const MODIFIER_CELLS = COLS * MODIFIER_ROWS;
const GAP = 2;

export const ModifierGrid: React.FC = () => {
  const { items, selectedItemId, draftItem, selectedModifierId, activeAction, activeModifierGroupId, setActiveModifierGroup, toggleModifier, selectItem, setModifierQuantity, updateQuantity } = useOrderStore();
  const modifierGroups = useMenuStore((s) => s.modifierGroups);
  const selectedItem = draftItem || items.find(i => i.id === selectedItemId);

  // Quantity mode → numpad
  if (activeAction === 'quantity' && selectedItem) {
    const isMod = !!selectedModifierId;
    let currentQty = selectedItem.quantity;
    let displayTitle = 'Кол-во порций';

    if (isMod && draftItem && selectedModifierId) {
      const mod = draftItem.modifiers.find(m => m.id === selectedModifierId);
      currentQty = draftItem.modifiers.filter(m => m.id === selectedModifierId).length;
      displayTitle = mod?.name ?? 'Кол-во порций';
    }

    return (
      <Numpad
        mode="quantity"
        value={String(currentQty)}
        onChange={(v) => {
          const newQty = parseInt(v) || 0;
          if (isMod && selectedModifierId) {
            setModifierQuantity(selectedModifierId, newQty);
          } else {
            const delta = newQty - currentQty;
            updateQuantity(selectedItem.id, delta);
          }
        }}
        title={displayTitle}
        accumulate={false}
      />
    );
  }

  // Comment mode → dish comment panel
  if (activeAction === 'comment' && selectedItem) {
    return <DishCommentPanel />;
  }

  // Delete mode → delete options
  if (activeAction === 'delete' && selectedItem) {
    return <DeleteOptions onDone={() => selectItem(null)} />;
  }

  // Modifier mode
  const isModifiers = activeAction === 'modifiers' && !!selectedItem;
  const availableGroups = selectedItem
    ? modifierGroups.filter(g => g.productIds.includes(selectedItem.product.id))
    : [];
  const activeGroup = availableGroups.find(g => g.id === activeModifierGroupId) || availableGroups[0];
  const currentGroupIdx = activeGroup ? availableGroups.findIndex(g => g.id === activeGroup.id) : -1;
  const modifiers = isModifiers && activeGroup ? activeGroup.modifiers : [];
  const headerTitle = isModifiers && activeGroup ? activeGroup.name : '';
  const itemModifierIds = selectedItem?.modifiers.map(m => m.id) || [];

  const handlePrevGroup = () => {
    if (currentGroupIdx > 0) {
      setActiveModifierGroup(availableGroups[currentGroupIdx - 1].id);
    }
  };

  const handleNextGroup = () => {
    if (currentGroupIdx < availableGroups.length - 1) {
      setActiveModifierGroup(availableGroups[currentGroupIdx + 1].id);
    }
  };

  // Build cells (только для модификаторных рядов — последний ряд занимает кнопка «Готово»)
  type Cell = { kind: 'modifier'; mod: Modifier } | { kind: 'empty' };
  const cells: Cell[] = modifiers.map(m => ({ kind: 'modifier' as const, mod: m }));
  while (cells.length < MODIFIER_CELLS) cells.push({ kind: 'empty' });

  const rows: Cell[][] = [];
  for (let r = 0; r < MODIFIER_ROWS; r++) {
    rows.push(cells.slice(r * COLS, r * COLS + COLS));
  }

  // Заглушки для рендера пустых рядов в empty-state (когда у блюда нет групп модификаторов),
  // чтобы общая высота правой колонки не менялась.
  const emptyRows: Cell[][] = [];
  for (let r = 0; r < MODIFIER_ROWS; r++) {
    emptyRows.push(Array.from({ length: COLS }, () => ({ kind: 'empty' as const })));
  }

  const renderModifierRows = (source: Cell[][]) =>
    source.map((row, ri) => (
      <View key={ri} style={[styles.row, { marginBottom: GAP }]}>
        {row.map((cell, ci) => (
          <View key={ci} style={[styles.cellWrap, ci < COLS - 1 && { marginRight: GAP }]}>
            {cell.kind === 'modifier' ? (
              <TouchableOpacity
                style={[styles.modBtn, itemModifierIds.includes(cell.mod.id) && styles.modActive]}
                onPress={() => toggleModifier(cell.mod)}
                activeOpacity={0.7}
              >
                <Text
                  style={[styles.modText, itemModifierIds.includes(cell.mod.id) && styles.modTextActive]}
                  numberOfLines={2}
                >
                  {cell.mod.name}
                </Text>
              </TouchableOpacity>
            ) : (
              <View style={styles.emptyCell} />
            )}
          </View>
        ))}
      </View>
    ));

  // No modifier panel needed — show empty state
  if (!isModifiers) {
    return (
      <View style={styles.container}>
        <View style={styles.header}>
          <View style={styles.headerBack} />
          <Text style={styles.headerText}>{selectedItem?.product.name || ''}</Text>
          <View style={styles.headerBack} />
        </View>
        <View style={styles.grid}>
          {renderModifierRows(emptyRows)}
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.headerBack} onPress={handlePrevGroup}>
          <ChevronLeftIcon size={22} color={currentGroupIdx > 0 ? theme.colors.textPrimary : theme.colors.textSecondary} />
        </TouchableOpacity>
        <Text style={styles.headerText}>{headerTitle}</Text>
        <TouchableOpacity style={styles.headerBack} onPress={handleNextGroup}>
          {currentGroupIdx < availableGroups.length - 1 && (
            <ChevronRightIcon size={22} color={theme.colors.textPrimary} />
          )}
        </TouchableOpacity>
      </View>

      <View style={styles.grid}>
        {renderModifierRows(rows)}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    height: 44,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.colors.surfaceLight,
    marginBottom: GAP,
  },
  headerBack: { width: 44, justifyContent: 'center', alignItems: 'center' },
  headerText: { flex: 1, color: theme.colors.textPrimary, fontSize: 16, fontFamily: theme.fonts.medium, textAlign: 'center' },

  grid: { flex: 1 },
  row: { flex: 1, flexDirection: 'row' },
  cellWrap: { flex: 1 },

  modBtn: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: theme.colors.surfaceLight,
    paddingHorizontal: 4,
  },
  modActive: {
    backgroundColor: theme.colors.white,
  },
  modText: {
    color: theme.colors.textPrimary,
    fontSize: 16,
    fontFamily: theme.fonts.regular,
    textAlign: 'center',
  },
  modTextActive: {
    color: theme.colors.textDark,
    fontFamily: theme.fonts.medium,
  },
  emptyCell: { flex: 1, backgroundColor: theme.colors.surfaceLight },

});
