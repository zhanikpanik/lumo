import React, { useEffect, useRef, useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, SafeAreaView, StatusBar, Alert } from 'react-native';
import { theme } from '../theme/colors';
import { Numpad } from '../components/Numpad';
import { useOrderStore } from '../store/orderStore';
import { useShiftStore } from '../store/shiftStore';
import { useSyncOutboxStore, formatRpcError } from '../store/syncOutboxStore';
import { can } from '../utils/permissions';
import { finalizeOrderConsumption } from '../api/inventory';
import { insertPayment } from '../api/payments';
import { VENUE_ID } from '../config';
import { saleConsumptionIdempotencyKey } from '../types/inventory';
import { logger } from '../utils/logger';
import { supabase } from '../utils/supabase';
import type { Order } from '../types';

const formatAmount = (n: number) => n.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ');

type PaymentMethod = 'cash' | 'card' | 'none';

const generatePaymentAttemptId = () => {
  // UUID v4-подобный — для идемпотентности достаточно энтропии Math.random.
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
};

const CLOSE_REASONS = [
  'За счёт заведения',
  'Ошибка официанта',
  'Ошибка кухни',
  'Гость ушёл',
  'Другое',
];

export const PaymentScreen: React.FC<{ navigation?: any }> = ({ navigation }) => {
  const { currentOrderId, items, getTotal } = useOrderStore();
  const currentUser = useShiftStore((s) => s.currentUser);
  const [method, setMethod] = useState<PaymentMethod>('cash');
  const [cashInput, setCashInput] = useState('');
  const [printReceipt, setPrintReceipt] = useState(true);
  const [closeReason, setCloseReason] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  // Стабильный per-сессия id попытки оплаты: повторный тап «Оплатить» / сетевой
  // retry попадают в тот же idempotency_key и не дублируют запись в payments.
  // Новый заход на PaymentScreen (например, после refund) даст новый attempt_id.
  const paymentAttemptId = useRef<string>(generatePaymentAttemptId());

  // Если компонент остался примонтированным (react-navigation stack), но
  // currentOrderId сменился (открыли другой заказ) — нужен свежий attemptId,
  // иначе idempotency_key первого заказа не пересечётся (orderId другой),
  // но лучше быть чистым и не полагаться на это.
  useEffect(() => {
    paymentAttemptId.current = generatePaymentAttemptId();
  }, [currentOrderId]);

  const total = getTotal();
  const canCloseWithoutPayment = can(currentUser?.role, 'closeWithoutPayment');
  const cashAmount = cashInput ? parseInt(cashInput, 10) : 0;
  const change = cashAmount > total ? cashAmount - total : 0;
  const canPay = method === 'card'
    || (method === 'none' && canCloseWithoutPayment && closeReason !== null)
    || (method === 'cash' && cashAmount >= total);

  const handleExact = () => {
    setCashInput(String(total));
  };

  const handlePay = async () => {
    if (isProcessing) return;
    if (!canPay || !currentOrderId) return;
    if (method === 'none' && !canCloseWithoutPayment) return;

    const shiftId = useShiftStore.getState().currentShift?.id ?? null;
    if (!shiftId) {
      Alert.alert('Смена не открыта', 'Сначала откройте смену.');
      navigation?.replace('OpenShift');
      return;
    }

    setIsProcessing(true);
    try {
      // Стабильный ключ повторного нажатия / сетевого retry в рамках сессии экрана.
      const idempotencyKey = `${currentOrderId}:${method}:${paymentAttemptId.current}`;

      const payResult = await insertPayment({
        orderId: currentOrderId,
        shiftId,
        method,
        amount: total,
        cashAmount,
        closeReason,
        idempotencyKey,
      });

      if (!payResult.ok && !payResult.isIdempotencyConflict) {
        Alert.alert('Ошибка оплаты', payResult.error ?? 'Неизвестная ошибка');
        return;
      }

      const isIdempotencyConflict = payResult.isIdempotencyConflict ?? false;

      if (method !== 'none' && !isIdempotencyConflict) {
        useShiftStore.getState().recordPayment(method, total);
        void useShiftStore.getState().refreshShiftCashSummary();
      }

      // Update local state immediately — UI responds right away
      const closedAt = new Date().toISOString();
      const newStatus = method === 'none' ? ('cancelled' as const) : ('paid' as const);
      useOrderStore.setState((state) => ({
        orders: state.orders.map((o) =>
          o.id === currentOrderId
            ? {
                ...o,
                status: newStatus,
                closedAt,
                closeReason: method === 'none' ? (closeReason ?? '') : undefined,
              }
            : o
        ),
      }));

      // Fire-and-forget: sync to Supabase in background, don't block navigation
      if (method !== 'none') {
        const os = useOrderStore.getState();
        const base = os.orders.find((o) => o.id === currentOrderId);
        if (base) {
          const paidOrder: Order = {
            ...base,
            items: os.items,
            totalAmount: os.getTotal(),
            status: 'paid',
            closedAt,
          };

          // Background sync: items + order + consumption + outbox — all in parallel, none block UI
          void (async () => {
            try {
              await os.flushPendingItemsToServer();
            } catch (e) {
              logger.error('payment.flushPendingItemsToServer', e, { orderId: currentOrderId });
            }
            try {
              await os.syncRemoteOrder(paidOrder);
            } catch (e) {
              logger.error('payment.syncRemoteOrder', e, { orderId: currentOrderId });
            }

            const consumptionIdemKey = saleConsumptionIdempotencyKey(currentOrderId);
            const payload = {
              venueId: VENUE_ID,
              orderId: currentOrderId,
              occurredAt: closedAt,
              idempotencyKey: consumptionIdemKey,
              shiftId: shiftId,
              lines: os.items.map((i) => ({
                order_item_id: i.id,
                product_id: i.product.id,
                quantity: i.quantity,
                modifier_ids: i.modifiers.map((m) => m.id),
              })),
            };

            try {
              const res = await finalizeOrderConsumption(payload);
              if (!res.ok) {
                logger.warn(
                  'payment.finalizeOrderConsumption.enqueue',
                  formatRpcError(res.error, res.detail),
                  { orderId: currentOrderId, detail: res.detail },
                );
                useSyncOutboxStore.getState().enqueueConsumption(payload);
              }
            } catch (e) {
              logger.error('payment.finalizeOrderConsumption', e, { orderId: currentOrderId });
              useSyncOutboxStore.getState().enqueueConsumption(payload);
            }

            void useSyncOutboxStore.getState().flush();
          })();
        }
      }

      useOrderStore.getState().closeOrder();

      // Log order event (paid or cancelled)
      if (newStatus === 'cancelled') {
        supabase.from('order_events').insert({
          order_id: currentOrderId,
          action: 'cancelled',
          occurred_at: closedAt,
          venue_id: VENUE_ID,
        }).then(({ error }) => {
          if (error) logger.error('payment.orderEvents.cancelled', error, { orderId: currentOrderId });
        });
      } else if (newStatus === 'paid') {
        supabase.from('order_events').insert({
          order_id: currentOrderId,
          action: 'paid',
          occurred_at: closedAt,
          venue_id: VENUE_ID,
        }).then(({ error }) => {
          if (error) logger.error('payment.orderEvents.paid', error, { orderId: currentOrderId });
        });
      }

      navigation?.navigate('Orders');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleCancel = () => {
    navigation?.goBack();
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar hidden />
      <View style={styles.root}>
        {/* ── Left Panel ── */}
        <View style={styles.leftPanel}>
          {/* Total */}
          <View style={styles.totalSection}>
            <Text style={styles.totalLabel}>Итого</Text>
            <Text style={styles.totalAmount}>{formatAmount(total)} c</Text>
          </View>

          {/* Payment method */}
          <View style={styles.methodSection}>
            <TouchableOpacity
              style={[styles.methodBtn, method === 'cash' && styles.methodActive]}
              onPress={() => { setMethod('cash'); setCashInput(''); setCloseReason(null); }}
              activeOpacity={0.7}
            >
              <Text style={[styles.methodText, method === 'cash' && styles.methodTextActive]}>
                Наличные
              </Text>
            </TouchableOpacity>
            <View style={{ width: 8 }} />
            <TouchableOpacity
              style={[styles.methodBtn, method === 'card' && styles.methodActive]}
              onPress={() => { setMethod('card'); setCloseReason(null); }}
              activeOpacity={0.7}
            >
              <Text style={[styles.methodText, method === 'card' && styles.methodTextActive]}>
                Карта
              </Text>
            </TouchableOpacity>
          </View>

          <View style={styles.methodSection}>
            <TouchableOpacity
              style={[
                styles.methodBtn,
                method === 'none' && styles.methodActiveRed,
                !canCloseWithoutPayment && styles.methodBtnDisabled,
              ]}
              onPress={() => {
                if (!canCloseWithoutPayment) return;
                setMethod('none');
                setCashInput('');
                setCloseReason(null);
              }}
              disabled={!canCloseWithoutPayment}
              activeOpacity={0.7}
            >
              <Text style={[styles.methodText, method === 'none' && styles.methodTextActive]}>
                Без оплаты
              </Text>
            </TouchableOpacity>
          </View>
          {!canCloseWithoutPayment && (
            <Text style={styles.permissionHint}>Без оплаты доступно только кассиру</Text>
          )}

          {/* Cash change info */}
          {method === 'cash' && cashAmount > 0 && cashAmount >= total && (
            <View style={styles.changeSection}>
              <Text style={styles.changeLabel}>Сдача</Text>
              <Text style={styles.changeAmount}>{formatAmount(change)} c</Text>
            </View>
          )}

          {/* Print receipt toggle */}
          <TouchableOpacity
            style={styles.receiptToggle}
            onPress={() => setPrintReceipt(!printReceipt)}
            activeOpacity={0.7}
          >
            <View style={[styles.checkbox, printReceipt && styles.checkboxChecked]}>
              {printReceipt && <Text style={styles.checkmark}>✓</Text>}
            </View>
            <Text style={styles.receiptText}>Напечатать чек</Text>
          </TouchableOpacity>

          {/* Spacer */}
          <View style={{ flex: 1 }} />

          {/* Action buttons */}
          <View style={styles.actionRow}>
            <TouchableOpacity
              style={[styles.cancelBtn, isProcessing && styles.payBtnDisabled]}
              onPress={handleCancel}
              disabled={isProcessing}
              activeOpacity={0.7}
            >
              <Text style={styles.cancelText}>Отмена</Text>
            </TouchableOpacity>
            <View style={{ width: 8 }} />
            {method === 'none' ? (
              <TouchableOpacity
                style={[styles.payBtnRed, (!canPay || isProcessing) && styles.payBtnDisabled]}
                onPress={handlePay}
                disabled={!canPay || isProcessing}
                activeOpacity={0.7}
              >
                <Text style={styles.payText}>
                  {isProcessing ? 'Закрываем...' : 'Закрыть без оплаты'}
                </Text>
              </TouchableOpacity>
            ) : (
              <TouchableOpacity
                style={[styles.payBtn, (!canPay || isProcessing) && styles.payBtnDisabled]}
                onPress={handlePay}
                disabled={!canPay || isProcessing}
                activeOpacity={0.7}
              >
                <Text style={styles.payText}>
                  {isProcessing ? 'Обработка...' : 'Оплатить'}
                </Text>
              </TouchableOpacity>
            )}
          </View>
        </View>

        {/* ── Right Panel: Numpad ── */}
        <View style={styles.rightPanel}>
          {method === 'cash' ? (
            <Numpad
              mode="amount"
              value={cashInput}
              onChange={setCashInput}
              currency="c"
              maxDigits={7}
            >
              {/* Exact amount — between value and keys */}
              <TouchableOpacity
                style={[styles.exactBtn, { borderRadius: 0 }]}
                onPress={handleExact}
                activeOpacity={0.6}
              >
                <Text style={styles.exactText}>Без сдачи — {formatAmount(total)} c</Text>
              </TouchableOpacity>
            </Numpad>
          ) : method === 'card' ? (
            <View style={styles.cardMode}>
              <Text style={styles.cardIcon}>💳</Text>
              <Text style={styles.cardTitle}>Оплата картой</Text>
              <Text style={styles.cardAmount}>{formatAmount(total)} c</Text>
              <Text style={styles.cardHint}>Приложите карту к терминалу</Text>
            </View>
          ) : (
            <View style={styles.reasonPanel}>
              <Text style={styles.reasonTitle}>Укажите причину</Text>
              {CLOSE_REASONS.map((reason) => (
                <TouchableOpacity
                  key={reason}
                  style={[styles.reasonBtn, closeReason === reason && styles.reasonBtnActive]}
                  onPress={() => setCloseReason(reason)}
                  activeOpacity={0.7}
                >
                  <Text style={[styles.reasonText, closeReason === reason && styles.reasonTextActive]}>
                    {reason}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          )}
        </View>
      </View>
    </SafeAreaView>
  );
};

const GAP = 2;

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: theme.colors.background },
  root: { flex: 1, flexDirection: 'row', padding: 16 },

  // Left panel
  leftPanel: {
    flex: 0.4,
    marginRight: 16,
  },
  totalSection: {
    backgroundColor: theme.colors.surfaceLight,
    borderRadius: theme.borderRadius,
    padding: 24,
    marginBottom: 16,
  },
  totalLabel: {
    color: theme.colors.textSecondary,
    fontSize: 16,
    fontFamily: theme.fonts.regular,
    marginBottom: 8,
  },
  totalAmount: {
    color: theme.colors.textPrimary,
    fontSize: 48,
    fontFamily: theme.fonts.medium,
  },

  methodSection: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  methodBtn: {
    flex: 1,
    height: 56,
    backgroundColor: theme.colors.surfaceLight,
    borderRadius: theme.borderRadius,
    justifyContent: 'center',
    alignItems: 'center',
  },
  methodActive: {
    backgroundColor: theme.colors.actionMenuPurple,
  },
  methodActiveRed: {
    backgroundColor: theme.colors.destructive,
  },
  methodText: {
    color: theme.colors.textPrimary,
    fontSize: 16,
    fontFamily: theme.fonts.medium,
  },
  methodTextActive: {
    color: theme.colors.white,
    fontFamily: theme.fonts.medium,
  },
  methodBtnDisabled: {
    opacity: 0.45,
  },
  permissionHint: {
    color: theme.colors.warningSubtle,
    fontSize: 16,
    fontFamily: theme.fonts.regular,
    marginBottom: 12,
  },

  changeSection: {
    backgroundColor: theme.colors.surfaceLight,
    borderRadius: theme.borderRadius,
    padding: 20,
    marginBottom: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  changeLabel: {
    color: theme.colors.textSecondary,
    fontSize: 16,
    fontFamily: theme.fonts.regular,
  },
  changeAmount: {
    color: theme.colors.accent,
    fontSize: 28,
    fontFamily: theme.fonts.medium,
  },

  receiptToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.colors.surfaceLight,
    borderRadius: theme.borderRadius,
    padding: 16,
    marginBottom: 16,
  },
  checkbox: {
    width: 24,
    height: 24,
    borderRadius: 4,
    borderWidth: 2,
    borderColor: theme.colors.textSecondary,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  checkboxChecked: {
    backgroundColor: theme.colors.actionMenuPurple,
    borderColor: theme.colors.actionMenuPurple,
  },
  checkmark: {
    color: theme.colors.white,
    fontSize: 16,
    fontFamily: theme.fonts.medium,
  },
  receiptText: {
    color: theme.colors.textPrimary,
    fontSize: 16,
    fontFamily: theme.fonts.regular,
  },

  actionRow: {
    flexDirection: 'row',
    height: 56,
  },
  cancelBtn: {
    flex: 1,
    backgroundColor: theme.colors.destructive,
    borderRadius: theme.borderRadius,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cancelText: {
    color: theme.colors.white,
    fontSize: 16,
    fontFamily: theme.fonts.medium,
  },
  payBtn: {
    flex: 1.5,
    backgroundColor: theme.colors.accent,
    borderRadius: theme.borderRadius,
    justifyContent: 'center',
    alignItems: 'center',
  },
  payBtnRed: {
    flex: 1.5,
    backgroundColor: theme.colors.destructive,
    borderRadius: theme.borderRadius,
    justifyContent: 'center',
    alignItems: 'center',
  },
  payBtnDisabled: {
    opacity: 0.4,
  },
  payText: {
    color: theme.colors.white,
    fontSize: 16,
    fontFamily: theme.fonts.medium,
  },

  // Right panel
  rightPanel: {
    flex: 0.6,
  },

  numpadDisplay: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'baseline',
    backgroundColor: theme.colors.numpadBg,
    borderRadius: theme.borderRadius,
    padding: 24,
    marginBottom: 8,
  },
  displayValue: {
    color: theme.colors.textPrimary,
    fontSize: 48,
    fontFamily: theme.fonts.regular,
  },
  displayCurrency: {
    color: theme.colors.textSecondary,
    fontSize: 24,
    fontFamily: theme.fonts.regular,
    marginLeft: 8,
  },

  quickRow: {
    marginBottom: 8,
  },
  exactBtn: {
    height: 48,
    backgroundColor: theme.colors.surfaceLight,
    borderRadius: theme.borderRadius,
    justifyContent: 'center',
    alignItems: 'center',
  },
  exactText: {
    color: theme.colors.textPrimary,
    fontSize: 16,
    fontFamily: theme.fonts.medium,
  },

  numpad: {
    flex: 1,
  },
  numRow: {
    flex: 1,
    flexDirection: 'row',
    marginBottom: GAP,
  },
  keyWrap: {
    flex: 1,
    marginHorizontal: GAP / 2,
  },
  key: {
    flex: 1,
    backgroundColor: theme.colors.numpadBg,
    borderRadius: theme.borderRadius,
    justifyContent: 'center',
    alignItems: 'center',
  },
  keyText: {
    color: theme.colors.textPrimary,
    fontSize: 28,
    fontFamily: theme.fonts.regular,
  },

  // Card mode
  cardMode: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: theme.colors.numpadBg,
    borderRadius: theme.borderRadius,
  },
  cardIcon: {
    fontSize: 64,
      fontFamily: theme.fonts.regular,
    marginBottom: 16,
  },
  cardTitle: {
    color: theme.colors.textPrimary,
    fontSize: 24,
    fontFamily: theme.fonts.medium,
    marginBottom: 8,
  },
  cardAmount: {
    color: theme.colors.textPrimary,
    fontSize: 48,
    fontFamily: theme.fonts.medium,
    marginBottom: 16,
  },
  cardHint: {
    color: theme.colors.textSecondary,
    fontSize: 16,
    fontFamily: theme.fonts.regular,
  },
  confirmWarning: {
    color: theme.colors.destructiveLight,
    fontSize: 16,
    fontFamily: theme.fonts.medium,
  },
  reasonPanel: {
    flex: 1,
    padding: 16,
  },
  reasonTitle: {
    color: theme.colors.textPrimary,
    fontSize: 16,
    fontFamily: theme.fonts.medium,
    marginBottom: 16,
  },
  reasonBtn: {
    height: 56,
    backgroundColor: theme.colors.surfaceLight,
    borderRadius: theme.borderRadius,
    justifyContent: 'center',
    paddingHorizontal: 20,
    marginBottom: 8,
  },
  reasonBtnActive: {
    backgroundColor: theme.colors.destructive,
  },
  reasonText: {
    color: theme.colors.textPrimary,
    fontSize: 16,
    fontFamily: theme.fonts.regular,
  },
  reasonTextActive: {
    color: theme.colors.white,
    fontFamily: theme.fonts.medium,
  },
});
